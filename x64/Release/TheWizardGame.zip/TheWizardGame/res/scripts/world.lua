world = {
  {
    name="test",
    pos = {
      
    }
  }
}
