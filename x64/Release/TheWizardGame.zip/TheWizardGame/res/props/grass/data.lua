grass = {
	{
		name = "grass",
		r = 0.15,
		g = 0.35,
		b = 0.02
	}
}
