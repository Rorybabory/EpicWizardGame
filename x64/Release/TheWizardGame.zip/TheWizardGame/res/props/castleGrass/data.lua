castleGrass = {
	-- {
	-- 	name = "grassBlades",
	-- 	r = 0.0,
	-- 	g = 0.38,
	-- 	b = 0.0
	-- },
	{
		name = "grassBase",
		r = 0.482,
		g = 0.98,
		b = 0.482
	},
}
