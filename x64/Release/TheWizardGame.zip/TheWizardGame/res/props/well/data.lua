well = {
	{
		name = "stone",
		r = 0.2,
		g = 0.2,
		b = 0.22
	},
	{
		name = "bucket",
		r = 0.349,
		g = 0.247,
		b = 0.09
	},
	{
		name = "frame",
		r = 0.349,
		g = 0.247,
		b = 0.09
	},
	{
		name = "roof",
		r = 0.349,
		g = 0.09,
		b = 0.09
	},
	{
		name = "rope",
		r=0.667,
		g=0.49,
		b=0.224
	}
}
