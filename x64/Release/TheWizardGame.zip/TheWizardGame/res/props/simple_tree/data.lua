simple_tree = {
	{
		name = "tree",
		r = 0.29,
		g = 0.58,
		b = 0.27
	}
}
