crate = {
	{
		name = "Frame",
		r = 0.349,
		g = 0.247,
		b = 0.09
	},
	{
		name = "Body",
		r=0.667,
		g=0.49,
		b=0.224
	}
}
