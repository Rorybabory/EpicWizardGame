mainCastle = {
	{
		name = "castleMain",
		r = 0.15,
		g = 0.15,
		b = 0.15
	},
	{
		name = "door",
		r = 0.545,
		g = 0.271,
		b = 0.075
	}
}
