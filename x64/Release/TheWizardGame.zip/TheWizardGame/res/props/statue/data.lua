statue = {
	{
		name = "mainBody",
		r = 0.2,
		g = 0.2,
		b = 0.22
	},
	{
		name = "BodyShadow",
		r = 0.1,
		g = 0.1,
		b = 0.11
	},
	{
		name = "mainBase",
		r=0.667,
		g=0.49,
		b=0.224
	},
	{
		name = "BaseShadow",
		r = 0.349,
		g = 0.247,
		b = 0.09
	},
	{
		name = "Crown",
		r = 0.2,
		g = 0.2,
		b = 0.22
	},
}
