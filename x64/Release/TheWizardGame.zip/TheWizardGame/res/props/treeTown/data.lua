treeTown = {
	{
		name = "base",
		r = 0.482,
		g = 0.98,
		b = 0.482
	},
	{
		name = "treeLeaves",
		r = 0.071,
		g = 0.282,
		b = 0.071
	},
	{
		name = "treeBark",
		r = 0.349,
		g = 0.247,
		b = 0.09
	},
	{
		name = "stoneBricks",
		r = 0.3,
		g = 0.3,
		b = 0.32
	}
}
