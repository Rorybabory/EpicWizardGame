pineTree = {
	{
		name = "leaves",
		r = 0.29,
		g = 0.58,
		b = 0.27
	},
	{
		name = "trunk",
		r = 0.545,
		g = 0.271,
		b = 0.075
	},
}
