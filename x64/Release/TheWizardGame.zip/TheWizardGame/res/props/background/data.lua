background = {
	{
		name = "Mountains",
		r = 0.15,
		g = 0.15,
		b = 0.17
	},
}
