barrel = {
	{
		name = "Frame",
		r = 0.2,
		g = 0.2,
		b = 0.22
	},
	{
		name = "Body",
		r = 0.349,
		g = 0.247,
		b = 0.09
	}
}
