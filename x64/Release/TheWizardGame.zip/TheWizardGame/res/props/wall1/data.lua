wall1 = {
	{
		name = "wall",
		r = 0.3,
		g = 0.3,
		b = 0.32
	},
	{
		name = "wallShadow",
		r = 0.2,
		g = 0.2,
		b = 0.22
	},
}
 