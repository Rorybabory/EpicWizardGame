tower = {
	{
		name = "Frame",
		r=0.667,
		g=0.49,
		b=0.224
	},
	{
		name = "Body",
		r = 0.349,
		g = 0.247,
		b = 0.09
	},
	{
		name = "Light",
		r = 1.0,
		g = 0.76,
		b = 0.49
	}
}
