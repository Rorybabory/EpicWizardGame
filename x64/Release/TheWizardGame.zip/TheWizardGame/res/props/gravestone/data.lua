gravestone = {
	{
		name = "main",
		r = 0.031373,
		g = 0.145098,
		b = 0.219608
	},
	{
		name = "shadow",
		r = 0.0078,
		g = 0.058824,
		b = 0.101961
	}
}
