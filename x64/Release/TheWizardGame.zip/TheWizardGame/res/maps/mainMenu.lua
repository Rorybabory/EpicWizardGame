mainMenu = {
    {
        type = "entity",
        file = "mainMenu",
        x = -60.0,
        y = 0.0,
    }
}
